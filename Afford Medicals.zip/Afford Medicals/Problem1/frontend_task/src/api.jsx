const BASE_URL = 'http://20.244.56.144/test/';

export const fetchProducts = async (companyName, categoryName, minPrice, maxPrice, topN) => {
  const url = `${BASE_URL}/companies/${companyName}/categories/${categoryName}/products?top=${topN}&minPrice=${minPrice}&maxPrice=${maxPrice}`;
  
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    return await response.json();
  } catch (error) {
    console.error('Error fetching products:', error);
    return [];
  }
};
